from fastapi import APIRouter, UploadFile, File, HTTPException
from pydantic import BaseModel
from app.ingestion.processor import process_document
from app.retrieval.vector_store import get_relevant_chunks
from app.rag.generator import generate_answer
from typing import List
import os
import json
from datetime import datetime

router = APIRouter()

class QuestionRequest(BaseModel):
    question: str

@router.post("/upload-docs")
async def upload_docs(files: List[UploadFile] = File(...)):
    if len(files) > 20:
        raise HTTPException(status_code=400, detail="Maximum 20 files allowed.")
    os.makedirs("uploads", exist_ok=True)
    for file in files:
        content = await file.read()
        file_path = os.path.join("uploads", file.filename)
        with open(file_path, "wb") as f:
            f.write(content)
        process_document(file_path)
    return {"status": "success", "files": [file.filename for file in files]}

@router.post("/query")
async def query_rag(payload: QuestionRequest):
    question = payload.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question is required.")
    try:
        chunks = get_relevant_chunks(question)
        answer = generate_answer(question, chunks)

        os.makedirs("logs", exist_ok=True)
        with open("logs/query_log.jsonl", "a") as log:
            log.write(json.dumps({
                "timestamp": datetime.utcnow().isoformat(),
                "question": question,
                "answer": answer
            }) + "\n")

        return {"answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/documents")
def list_documents():
    files = os.listdir("uploads") if os.path.exists("uploads") else []
    return {"documents": files}
