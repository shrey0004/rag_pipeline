import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

client = chromadb.Client()
collection = client.get_or_create_collection(name="documents")

def get_relevant_chunks(query: str, k: int = 5):
    results = collection.query(
        query_texts=[query],
        n_results=k,
    )
    return results["documents"][0]
