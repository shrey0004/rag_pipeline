import fitz  # PyMuPDF
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
import os

model = SentenceTransformer("all-MiniLM-L6-v2")
client = chromadb.Client()
collection = client.get_or_create_collection(name="documents")

def process_document(file_path: str):
    doc = fitz.open(file_path)
    text_chunks = []
    for page in doc:
        text = page.get_text()
        text_chunks.extend([text[i:i+500] for i in range(0, len(text), 500)])

    embeddings = model.encode(text_chunks)
    ids = [f"{os.path.basename(file_path)}_chunk_{i}" for i in range(len(text_chunks))]
    collection.add(documents=text_chunks, embeddings=embeddings, ids=ids)
