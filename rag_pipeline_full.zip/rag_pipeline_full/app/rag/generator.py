import google.generativeai as genai
from app.core.config import GEMINI_API_KEY

genai.configure(api_key=GEMINI_API_KEY)

model = genai.GenerativeModel("models/gemini-pro")

def generate_answer(query: str, context_chunks: list):
    context = "\n".join(context_chunks)
    prompt = f"""Answer the question based on the context below:

Context:
{context}

Question: {query}

Answer:"""

    response = model.generate_content(prompt)

    # Defensive check
    if hasattr(response, "text"):
        return response.text.strip()
    elif hasattr(response, "candidates"):
        return response.candidates[0].content.parts[0].text.strip()
    else:
        return "Sorry, I couldn't generate a response."
