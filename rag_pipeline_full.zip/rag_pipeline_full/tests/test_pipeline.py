def test_dummy():
    assert 1 + 1 == 2
