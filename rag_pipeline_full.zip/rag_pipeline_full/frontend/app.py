import streamlit as st
import requests

st.title("🧠 Document Q&A Assistant")

backend_url = "http://localhost:8000"

st.sidebar.header("Upload PDFs")
uploaded_files = st.sidebar.file_uploader("Choose PDFs", accept_multiple_files=True, type=["pdf"])
if st.sidebar.button("Upload"):
    if uploaded_files:
        with st.spinner("Uploading..."):
            files = [("files", (f.name, f, "application/pdf")) for f in uploaded_files]
            res = requests.post(f"{backend_url}/upload-docs", files=files)
            st.sidebar.success("Upload complete!")
    else:
        st.sidebar.warning("No files selected.")

st.header("Ask a Question")
question = st.text_input("Enter your question")
if st.button("Get Answer") and question:
    with st.spinner("Thinking..."):
        res = requests.post(f"{backend_url}/query", json={"question": question})
        if res.status_code == 200:
            st.success(res.json()["answer"])
        else:
            st.error(f"Error: {res.json().get('detail', 'Unknown error')}")

if st.checkbox("Show Uploaded Documents"):
    res = requests.get(f"{backend_url}/documents")
    st.write(res.json()["documents"])
